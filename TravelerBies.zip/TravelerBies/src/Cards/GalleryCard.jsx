const GalleryCard = ({ image }) => {
  return (
    <>
      <img src={image} alt="" />
    </>
  );
};

export default GalleryCard;
