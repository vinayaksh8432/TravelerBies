import { h1, h2, h3, h4, comment, date } from "../assets";

const highlights = [
  {
    image: h1,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: h2,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: h3,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: h4,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
];
export { highlights };
