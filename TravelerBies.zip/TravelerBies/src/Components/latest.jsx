import { l1, l2, l3, l4, comment, date } from "../assets";

const latest = [
  {
    image: l1,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: l2,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: l3,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: l4,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
];
export { latest };
