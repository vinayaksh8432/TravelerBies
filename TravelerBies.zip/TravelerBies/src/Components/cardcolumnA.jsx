import { c1, c2, commentBlack, dateBlack } from "../assets";

const cardcolumnA = [
  {
    image: c1,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: c2,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
];
export { cardcolumnA };
