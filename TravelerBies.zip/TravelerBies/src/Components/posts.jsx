import { post1, post2, comment, date } from "../assets";

const posts = [
  {
    image: post1,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: post2,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
];
export { posts };
