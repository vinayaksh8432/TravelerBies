import { pop1, pop2, pop3, pop4, comment, date } from "../assets";

const mostpopular = [
  {
    image: pop1,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: pop2,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: pop3,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: pop4,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
];
export { mostpopular };
