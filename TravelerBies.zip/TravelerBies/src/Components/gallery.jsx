import { g1, g2, g3, g4, g5, g6 } from "../assets";

const gallery = [
  {
    image: g1,
  },
  {
    image: g2,
  },
  {
    image: g3,
  },
  {
    image: g4,
  },
  {
    image: g5,
  },
  {
    image: g6,
  },
];
export { gallery };
