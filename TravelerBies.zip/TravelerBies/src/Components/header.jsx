import { photo1, photo2, photo3, comment, date } from "../assets";

const header = [
  {
    image: photo1,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: photo2,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
  {
    image: photo3,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: comment,
    comment: "2 comments",
    dateIcon: date,
    date: "July 11, 2016",
  },
];
export { header };
