import {
  img1,
  img2,
  img3,
  img4,
  img5,
  img6,
  commentBlack,
  dateBlack,
} from "../assets";

const column = [
  {
    image: img1,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: img2,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: img3,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: img4,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: img5,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: img6,
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
];
export { column };
