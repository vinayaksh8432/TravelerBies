import { c3, c4, commentBlack, dateBlack } from "../assets";

const cardcolumnB = [
  {
    image: c3,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
  {
    image: c4,
    title: "LifeStyle",
    description: "Lorem ipsum is simply dummy Text of the printing",
    commentIcon: commentBlack,
    comment: "2 comments",
    dateIcon: dateBlack,
    date: "July 11, 2016",
  },
];
export { cardcolumnB };
